package com.example.hr1.domain.main.dto;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class ReqUpdateMainDTO {
    private String regionName;

    
}
