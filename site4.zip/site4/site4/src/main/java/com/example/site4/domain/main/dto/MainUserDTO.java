package com.example.site4.domain.main.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class MainUserDTO {
  // 화면에 필요한 자료 가져옴.
  private Long idx;
  private String id;

}
