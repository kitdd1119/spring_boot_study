package com.example.site4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Site4Application {

	public static void main(String[] args) {
		SpringApplication.run(Site4Application.class, args);
	}

}
