package com.example.site4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Site4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
